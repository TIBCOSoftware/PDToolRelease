#!/bin/sh
#
# runs the PDToolGUI jetty instance

APPS_INSTALL_DIR="/Users/cgoodric/dev/PDTool62"

java -Dapps.install.dir=$APPS_INSTALL_DIR -jar $APPS_INSTALL_DIR/gui/target/PDToolGUI-0.1.0-SNAPSHOT.jar server $APPS_INSTALL_DIR/gui/PDToolGUI.yml
