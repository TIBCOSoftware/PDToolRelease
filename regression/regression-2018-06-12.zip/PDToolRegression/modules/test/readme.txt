this folder is to store test files such as output car files or any other test file associated with the module xml.

Prior to running a test, delete all files except the readme.txt